// ==UserScript==
// @name         CSND免登录复制
// @version      1.0
// @description  CSND免登录复制
// @author       You
// @match        https://blog.csdn.net/*/article/details/*
// @icon         https://g.csdnimg.cn/static/logo/favicon32.cio
// ==/UserScript==

(function() {
    'use strict';

    let codes = document.querySelectorAll("code");
    codes.forEach(c => {
        c.contentEditable = "true";
    });
})();